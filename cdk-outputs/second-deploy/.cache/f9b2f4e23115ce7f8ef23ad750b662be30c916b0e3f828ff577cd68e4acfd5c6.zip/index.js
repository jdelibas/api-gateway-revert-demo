export const handler = async () => {
    console.log('hello world');
}
